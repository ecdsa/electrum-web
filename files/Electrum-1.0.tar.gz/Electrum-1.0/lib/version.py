ELECTRUM_VERSION = "1.0"
SEED_VERSION = 4  # bump this everytime the seed generation is modified
TRANSLATION_ID = 28344 # version of the wiki page 
